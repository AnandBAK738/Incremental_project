export interface Booking{
    bookingId?:number;
    flightId?:number;
    userId?:number;
    bookingDate?:Date;
    numberOfPassengers?:number;
    status?:string;

}
package com.examly.springapp.exception;

public class DuplicateFlightException extends Exception{
    public DuplicateFlightException(String msg){
        super(msg);
    }
}

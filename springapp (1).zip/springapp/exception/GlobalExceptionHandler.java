package com.examly.springapp.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SeatsExceededException.class)
    public ResponseEntity<?> handleSeatsExceededException(SeatsExceededException e){
        return ResponseEntity.status(400).body(e.getMessage());
    }
    @ExceptionHandler(DuplicateFlightException.class)
    public ResponseEntity<?> handleDuplicateFlightException(DuplicateFlightException e){
        return ResponseEntity.status(400).body(e.getMessage());
    }
    @ExceptionHandler(FlightDetailsnotFoundException.class)
    public ResponseEntity<?> handleFlightDetailsnotFoundException(FlightDetailsnotFoundException e){
        return ResponseEntity.status(400).body(e.getMessage());
    }
    @ExceptionHandler(BookingsException.class)
    public ResponseEntity<String> handleBookingsException(BookingsException e){
        return ResponseEntity.status(400).body(e.getMessage());
    }
    @ExceptionHandler(UserNameNotFound.class)
    public ResponseEntity<String> handleUserNameNotFound(UserNameNotFound e){
        return ResponseEntity.status(400).body(e.getMessage());
    }

}

package com.examly.springapp.exception;

public class FlightDetailsnotFoundException  extends Exception{
    public FlightDetailsnotFoundException(String msg){
        super(msg);
    }
    
    
}

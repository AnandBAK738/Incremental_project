package com.examly.springapp.exception;

public class BookingsException  extends Exception{
    public BookingsException(String msg){
        super(msg);
    }
}

package com.examly.springapp.exception;

public class SeatsExceededException extends Exception {
    public SeatsExceededException(String msg){
        super(msg);
    }
}

package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.Booking;

@Repository
public interface BookingRepo extends JpaRepository<Booking,Long> {
    @Query("select b from Booking b where b.flight.flightNumber=?1 and b.bookingDate=?2")
    List<Booking> getAllBookingByDate(String flightNumber, String bookingDate);
    // @Query("select sum(b.numberOfPassengers) from Booking b where b.flightNumber=?1 and b.bookingDate=?2")
    // Long getAllBookingByDate(String flightNumber, String bookingDate);

    @Query("select b from Booking b where b.user.userId=?1")
    List<Booking> getAllBookingsForUser(int userId);

}

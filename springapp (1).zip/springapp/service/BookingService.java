package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.exception.BookingsException;
import com.examly.springapp.exception.FlightDetailsnotFoundException;
import com.examly.springapp.exception.SeatsExceededException;
import com.examly.springapp.model.Booking;

public interface BookingService {
    Booking createBooking(Booking booking) throws SeatsExceededException, FlightDetailsnotFoundException;
    Booking getBookingById(Long id) throws BookingsException;
    List<Booking> getAllBookings() throws BookingsException;
    Booking updateBooking(Long id,Booking booking) throws BookingsException;
    List<Booking> getAllBookingsByUserId(int userId);
   
    

}

package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.BookingsException;
import com.examly.springapp.exception.FlightDetailsnotFoundException;
import com.examly.springapp.exception.SeatsExceededException;
import com.examly.springapp.model.Booking;
import com.examly.springapp.model.Flight;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.BookingRepo;
import com.examly.springapp.repository.FlightRepo;
import com.examly.springapp.repository.UserRepo;
@Service
public class BookingServiceImpl implements BookingService {
    @Autowired
    BookingRepo bookingRepo;
    @Autowired
    FlightRepo flightRepo;
    @Autowired
    UserRepo userRepo;
    @Override
    public Booking createBooking(Booking booking) throws SeatsExceededException, FlightDetailsnotFoundException {
        Flight flight=flightRepo.findByFlightNumber(booking.getFlight().getFlightNumber());
        if(flight!=null){
            List<Booking> totalBookings=bookingRepo.getAllBookingByDate(booking.getFlight().getFlightNumber(),booking.getBookingDate());
            int totalSeats=0;
            for(Booking b:totalBookings){
                totalSeats=totalSeats+b.getNumberOfPassengers();
            }

            if(flight.getTotalSeats()-totalSeats>=booking.getNumberOfPassengers()){
                booking.setFlight(flight);
                booking=bookingRepo.save(booking);  
                return booking; 
            }
            else{
                throw new SeatsExceededException("Seats are not available.");
            }
        }   
         throw new FlightDetailsnotFoundException("Flight Not available."); 
       
    }

    @Override
    public Booking getBookingById(Long id) throws BookingsException  {
        Booking booking=bookingRepo.findById(id).orElse(null);
        if(booking==null){
            throw new BookingsException("Booking ID: "+id+" doesn't exist.");
        }
        return booking;
    }

    @Override
    public List<Booking> getAllBookings() throws BookingsException {
        List<Booking> listOfbookings=bookingRepo.findAll();
        if(listOfbookings.size()==0){
            throw new BookingsException("There are no bookings exist.");
        }
        return listOfbookings;
    }

    @Override
    public Booking updateBooking(Long id, Booking booking) throws BookingsException {
        Booking b=bookingRepo.findById(id).orElse(null);
        if(b!=null){
            booking.setBookingId(id);
            bookingRepo.save(booking);
            return booking;
        }
        throw new BookingsException("Booking ID: "+id+" doesn't exist.");
    }

    @Override
    public List<Booking> getAllBookingsByUserId(int userId) {
        User user=userRepo.findById(userId).orElse(null);
        if(user!=null){
            List<Booking> bookings=bookingRepo.getAllBookingsForUser(userId);
            return bookings;
        }
        return null;
    }

  
    
}

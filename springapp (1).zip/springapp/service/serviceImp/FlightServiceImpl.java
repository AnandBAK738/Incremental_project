package com.examly.springapp.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.DuplicateFlightException;
import com.examly.springapp.exception.FlightDetailsnotFoundException;
import com.examly.springapp.model.Flight;
import com.examly.springapp.repository.FlightRepo;
import com.examly.springapp.service.FlightService;

@Service
public class FlightServiceImpl implements FlightService {
    @Autowired
    FlightRepo flightRepo;
    public Flight addFlight(Flight flight) throws DuplicateFlightException
    {
         Flight existingFlight=flightRepo.findByFlightNumber(flight.getFlightNumber());
         if(existingFlight!=null){
             throw new DuplicateFlightException("Flight with "+flight.getFlightNumber()+" already exists");
         }
        
        return flightRepo.save(flight);
    }
    public Flight updateFlight(long flightId,Flight flight) throws FlightDetailsnotFoundException{
        Flight getFlight=flightRepo.findById(flightId).orElse(null);
        if(getFlight!=null){
            flight.setFlightId(getFlight.getFlightId());
            flight=flightRepo.save(flight);
            return flight;
        }
        throw new FlightDetailsnotFoundException("Given Flight Id doesn't exist. Updation Failed.");
    }
    public List<Flight> getAllFlights() throws FlightDetailsnotFoundException{
        List<Flight> listOfFlights=flightRepo.findAll();
        if(listOfFlights.size()==0){
            throw new FlightDetailsnotFoundException("No Flights  exist");
        }
        return listOfFlights;
    }
    public Flight getFlightById(long flightId) throws FlightDetailsnotFoundException{
        Flight flight=flightRepo.findById(flightId).orElse(null);
        if(flight!=null){
            return flight;
        }
        throw new FlightDetailsnotFoundException("No Flight exists with "+flightId);
    }
    public boolean deleteFlightById(long flightId) throws FlightDetailsnotFoundException{
        Flight flight=flightRepo.findById(flightId).orElse(null);
      if (flight==null) {
        throw new FlightDetailsnotFoundException("Flight with ID "+flightId+" does not exist to delete");
      }
      flightRepo.deleteById(flightId);
      return true;
        
    }

}

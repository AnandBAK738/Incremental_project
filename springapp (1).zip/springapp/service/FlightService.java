package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.exception.DuplicateFlightException;
import com.examly.springapp.exception.FlightDetailsnotFoundException;
import com.examly.springapp.model.Flight;

public interface FlightService {
     Flight addFlight(Flight flight) throws FlightDetailsnotFoundException, DuplicateFlightException;
     Flight updateFlight(long flightId, Flight flight) throws FlightDetailsnotFoundException;
     List<Flight> getAllFlights() throws FlightDetailsnotFoundException;
     Flight getFlightById(long flightId) throws FlightDetailsnotFoundException;
     boolean deleteFlightById(long flightId) throws FlightDetailsnotFoundException;
}

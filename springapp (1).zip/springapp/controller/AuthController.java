package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exception.UserNameNotFound;
import com.examly.springapp.model.User;
import com.examly.springapp.service.UserService;

@RestController
@CrossOrigin
public class AuthController {
    @Autowired
    UserService userService;
    @PostMapping("/api/register")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User newUser=userService.createUser(user);
        return ResponseEntity.status(200).body(newUser);

    }
    // @PostMapping("/api/login")
    // public ResponseEntity<User> loginUser(@RequestBody User user){
    //     User userLog=userService.loginUser(user);
    //     return ResponseEntity.status(200).body(userLog);
    // }
    @GetMapping("/api/user/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable int userId) {
        User getUser=userService.getUserById(userId);
        return ResponseEntity.status(200).body(getUser);
    }
    @GetMapping("/api/user")
    public ResponseEntity<List<User>> getAllUsers(){
        List<User> getUsers=userService.getAllUsers();
        return ResponseEntity.status(200).body(getUsers);
    }
    @PostMapping("/api/login")
    public ResponseEntity<User> userLogin(@RequestBody User user) throws UserNameNotFound{
        User existingUser=userService.userLogin(user.getEmail(),user.getPassword());
        existingUser.setPassword(null);
        return ResponseEntity.status(200).body(existingUser);
    }
}

package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exception.DuplicateFlightException;
import com.examly.springapp.exception.FlightDetailsnotFoundException;
import com.examly.springapp.model.Flight;
import com.examly.springapp.service.FlightService;

@RestController
@CrossOrigin
public class FlightController {
    @Autowired
    FlightService flightService;
    @PostMapping("/api/flights")
    public ResponseEntity<Flight> addFlight(@RequestBody Flight flight) throws FlightDetailsnotFoundException, DuplicateFlightException{
        flight =flightService.addFlight(flight);
        return ResponseEntity.status(200).body(flight);

    }
    @PutMapping("/api/flights/{flightId}")
    public ResponseEntity<Flight> updateFlight(@PathVariable long flightId, @RequestBody Flight flight) throws FlightDetailsnotFoundException{
        flight=flightService.updateFlight(flightId, flight);
        return ResponseEntity.status(200).body(flight);
    }
    @GetMapping("/api/flights")
    public ResponseEntity<List<Flight>> getAllFlights() throws FlightDetailsnotFoundException{
        List<Flight> listOFlights=flightService.getAllFlights();
        return ResponseEntity.status(200).body(listOFlights);
        
    }
    @GetMapping("/api/flights/{flightId}")
    public ResponseEntity<Flight> getFlightById(@PathVariable long flightId) throws FlightDetailsnotFoundException{
        Flight flight=flightService.getFlightById(flightId);
        return ResponseEntity.status(200).body(flight);

    }
    @DeleteMapping("/api/flights/{flightId}")
    public ResponseEntity<Boolean> deleteFlightById(@PathVariable long flightId) throws FlightDetailsnotFoundException{
        boolean isFlightExist=flightService.deleteFlightById(flightId);
        return ResponseEntity.status(200).body(isFlightExist);
        
    }

}

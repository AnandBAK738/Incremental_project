package com.examly.springapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Flight;

@RestController
@CrossOrigin
public class TestController {
    private List<Flight> list =new ArrayList();
    @GetMapping("/api/test/welcome")
    public String welcome(){
        return "Welcome to the Flight Booking Application";
    }
    @GetMapping("/api/test/flights")
    public List<Flight> getFlightDetails(){
        return list;
    }
}

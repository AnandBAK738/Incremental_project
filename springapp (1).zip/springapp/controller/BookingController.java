package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.exception.BookingsException;
import com.examly.springapp.exception.FlightDetailsnotFoundException;
import com.examly.springapp.exception.SeatsExceededException;
import com.examly.springapp.model.Booking;
import com.examly.springapp.service.BookingService;

@RestController
@CrossOrigin
public class BookingController {
    @Autowired
    BookingService bookingService;
    @PostMapping("/api/bookings")
    public ResponseEntity<Booking> createBooking(@RequestBody Booking booking) throws SeatsExceededException, FlightDetailsnotFoundException{
        Booking newBooking=bookingService.createBooking(booking);
        return ResponseEntity.status(201).body(newBooking);
        
    }
    @GetMapping("/api/bookings/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable long id) throws BookingsException{
        Booking booking=bookingService.getBookingById(id);
        return ResponseEntity.status(200).body(booking); 
    }
    @GetMapping("/api/bookings/user/{userId}")
    public ResponseEntity<List<Booking>> getAllBookingsByUserId(@PathVariable int userId){
        List<Booking> listOfBookings=bookingService.getAllBookingsByUserId(userId);
        return ResponseEntity.status(200).body(listOfBookings); 
    }
    @GetMapping("/api/bookings")
    public ResponseEntity<List<Booking>> getAllBookings() throws BookingsException{
        List<Booking> listOfBookings=bookingService.getAllBookings();
        return ResponseEntity.status(200).body(listOfBookings); 
    }
    @PutMapping("/api/bookings/{id}")
    public ResponseEntity<Booking> updateBooking(@RequestBody Booking booking,@PathVariable long id) throws BookingsException{
        Booking updatedBooking=bookingService.updateBooking(id,booking);
        return ResponseEntity.status(200).body(updatedBooking); 
    }

    
}
